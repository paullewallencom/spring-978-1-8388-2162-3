package com.demo;

public interface GreetInterface {
    String greet();
}
